import android.app.Application

class MyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        MicroblinkSDK.setLicenseFile("C:/Users/manig/AndroidStudioProjects/VotingApp/app/src/main/assets/license.key", this)
    }
}