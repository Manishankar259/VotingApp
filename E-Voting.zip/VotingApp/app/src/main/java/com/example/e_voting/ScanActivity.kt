import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.microblink.activity.DocumentScanActivity
import com.microblink.entities.recognizers.RecognizerBundle
import com.microblink.entities.recognizers.blinkid.generic.BlinkIdCombinedRecognizer
import com.microblink.uisettings.ActivityRunner
import com.microblink.uisettings.BlinkIdUISettings

class ScanActivity : Activity() {
    private lateinit var recognizerBundle: RecognizerBundle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Here, we have to Initialize the recognizer
        val recognizer = BlinkIdCombinedRecognizer()
        recognizerBundle = RecognizerBundle(recognizer)
        val settings = BlinkIdUISettings(recognizerBundle)
        ActivityRunner.startActivityForResult(this, settings, 1)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            recognizerBundle.loadFromIntent(data)
            val recognizer = recognizerBundle.recognizers as BlinkIdCombinedRecognizer
            val result = recognizer.result
            if (result.resultState == Recognizer.Result.State.Valid) {
                val zipCode = result.address?.postalCode
                val returnIntent = Intent()
                returnIntent.putExtra("zipCode", zipCode)
                setResult(Activity.RESULT_OK, returnIntent)
                finish()
            }
        }
    }
}
