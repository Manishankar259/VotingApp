package com.example.e_voting

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class VoteActivity : AppCompatActivity() {

    private lateinit var editTextZipcode: EditText
    private lateinit var buttonSearchRegion: Button
    private lateinit var textViewRegion: TextView
    private lateinit var buttonSubmitVote: Button
    private var regionName = ""
    private var selectedCandidate: String? = null // To store the selected candidate

    private val db = FirebaseFirestore.getInstance()

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_vote)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        editTextZipcode = findViewById(R.id.zipcodeText)
        buttonSearchRegion = findViewById(R.id.buttonSearch)
        textViewRegion = findViewById(R.id.textView3)
        buttonSubmitVote = findViewById(R.id.button)

        val zipCode = intent.getStringExtra("zipCode")
        editTextZipcode.setText(zipCode)

        buttonSearchRegion.setOnClickListener {
            val zipcodeInput = editTextZipcode.text.toString().trim()

            if (zipcodeInput.length >= 3) {
                val firstThreeChars = zipcodeInput.substring(0, 3).uppercase()

                fetchRegionFromZipcode(firstThreeChars)
            } else {
                Toast.makeText(this@VoteActivity, "Please enter a valid zipcode", Toast.LENGTH_SHORT).show()
            }
        }

        buttonSubmitVote.setOnClickListener {
            if (selectedCandidate == null) {
                Toast.makeText(this, "Please select a candidate to vote!", Toast.LENGTH_SHORT).show()
            } else {
                // Show confirmation dialog
                AlertDialog.Builder(this)
                    .setTitle("Confirm Vote")
                    .setMessage("Are you sure you want to vote for $selectedCandidate?")
                    .setPositiveButton("Yes") { _, _ ->
                        registerVote(regionName, selectedCandidate!!)
                    }
                    .setNegativeButton("No", null)
                    .show()
            }
        }
    }

    private fun fetchRegionFromZipcode(zipcodeRef: String) {
        val docRef = db.collection("Zipcode").document(zipcodeRef)

        docRef.get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    val region = document.getString("region")
                    regionName = region.toString()
                    fetchCandidateName(region.toString())
                    if (region != null) {
                        textViewRegion.text = "Region: $region"
                    } else {
                        textViewRegion.text = "Region not found"
                        Log.d("Firestore", "Region field missing in document")
                    }
                } else {
                    textViewRegion.text = "Region not found"
                    Log.d("Firestore", "No such document")
                }
            }
            .addOnFailureListener { exception ->
                Log.w("Firestore", "Error fetching document", exception)
                Toast.makeText(this, "Error fetching region", Toast.LENGTH_SHORT).show()
            }
    }

    private fun fetchCandidateName(regionRef: String) {
        val docRefCan = db.collection("Regions").document(regionRef)
        docRefCan.get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    val candidatesList = document.get("candidates") as? List<Map<String, String>> ?: emptyList()
                    val formattedCandidates = candidatesList.map { candidate ->
                        "${candidate["name"]} (${candidate["party"]})"
                    }

                    updateRecyclerView(formattedCandidates)
                } else {
                    Log.d("Firestore", "No such document for region: $regionName")
                }
            }
            .addOnFailureListener { exception ->
                Log.w("Firestore", "Error fetching region document", exception)
            }
    }

